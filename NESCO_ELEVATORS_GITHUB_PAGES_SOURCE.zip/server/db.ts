import { and, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { Customer, InsertUser, Agreement, Quotation, customers, agreements, quotations, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function listCustomers(ownerOpenId: string): Promise<Customer[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(customers).where(eq(customers.ownerOpenId, ownerOpenId)).orderBy(desc(customers.updatedAt));
}

export async function saveCustomer(ownerOpenId: string, input: Omit<Customer, "id" | "ownerOpenId" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await db.select().from(customers).where(and(eq(customers.ownerOpenId, ownerOpenId), eq(customers.name, input.name))).limit(1);
  if (existing[0]) {
    await db.update(customers).set(input).where(eq(customers.id, existing[0].id));
    return existing[0].id;
  }
  await db.insert(customers).values({ ...input, ownerOpenId });
  return null;
}

export async function listQuotations(ownerOpenId: string): Promise<Quotation[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(quotations).where(eq(quotations.ownerOpenId, ownerOpenId)).orderBy(desc(quotations.updatedAt));
}

export async function saveQuotation(ownerOpenId: string, input: Omit<Quotation, "id" | "ownerOpenId" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(quotations).values({ ...input, ownerOpenId });
  return Number(result[0].insertId);
}

export async function saveAgreement(ownerOpenId: string, input: Omit<Agreement, "id" | "ownerOpenId" | "createdAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(agreements).values({ ...input, ownerOpenId });
}

export async function listAgreements(ownerOpenId: string): Promise<Agreement[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(agreements).where(eq(agreements.ownerOpenId, ownerOpenId)).orderBy(desc(agreements.createdAt));
}

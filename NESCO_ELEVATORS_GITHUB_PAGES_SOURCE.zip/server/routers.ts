import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { listAgreements, listCustomers, listQuotations, saveAgreement, saveCustomer, saveQuotation } from "./db";

const customerInput = z.object({
  name: z.string().min(1),
  address: z.string().min(1),
  contact: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().optional(),
  site: z.string().optional(),
});
const payloadInput = z.record(z.string(), z.unknown());

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  quotations: router({
    customers: router({
      list: adminProcedure.query(({ ctx }) => listCustomers(ctx.user.openId)),
      save: adminProcedure.input(customerInput).mutation(({ ctx, input }) => saveCustomer(ctx.user.openId, { name: input.name, address: input.address, contact: input.contact ?? null, phone: input.phone ?? null, email: input.email ?? null, site: input.site ?? null })),
    }),
    history: adminProcedure.query(({ ctx }) => listQuotations(ctx.user.openId)),
    save: adminProcedure.input(z.object({
      customerId: z.number().int().optional(),
      quoteNo: z.string().min(1),
      template: z.string().min(1),
      status: z.string().default("draft"),
      total: z.number().int().nonnegative(),
      payload: payloadInput,
    })).mutation(({ ctx, input }) => saveQuotation(ctx.user.openId, { customerId: input.customerId ?? null, quoteNo: input.quoteNo, template: input.template, status: input.status, total: input.total, payload: JSON.stringify(input.payload) })),
    agreements: adminProcedure.query(({ ctx }) => listAgreements(ctx.user.openId)),
    createAgreement: adminProcedure.input(z.object({
      quotationId: z.number().int().optional(),
      plan: z.string().min(1),
      payload: payloadInput,
    })).mutation(({ ctx, input }) => saveAgreement(ctx.user.openId, { quotationId: input.quotationId ?? null, plan: input.plan, payload: JSON.stringify(input.payload) })),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;

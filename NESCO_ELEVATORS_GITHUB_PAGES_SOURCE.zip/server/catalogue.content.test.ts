import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("NESCO catalogue content contracts", () => {
  const homeSource = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");

  it("includes the Commercial Lifts product and dedicated product detail route", () => {
    expect(homeSource).toContain('"Commercial Lifts"');
    expect(homeSource).toContain('"/products/commercial-lifts"');
    expect(homeSource).toContain("product-tiles");
    expect(homeSource).toContain("product-tile-image");
  });

  it("includes dedicated service detail routes with visual support", () => {
    expect(homeSource).toContain('"/services/new-installation"');
    expect(homeSource).toContain('"/services/site-survey"');
    expect(homeSource).toContain("detail-page-image");
    expect(homeSource).toContain("PROJECT VISUAL");
  });

  it("includes image-led service tiles with clickable detail routes", () => {
    expect(homeSource).toContain("service-tiles");
    expect(homeSource).toContain("service-tile-image");
    expect(homeSource).toContain('"/services/electrical-solutions"');
  });

  it("includes a visible fallback control for the hero video", () => {
    expect(homeSource).toContain("hero-video-toggle");
    expect(homeSource).toContain("Pause intro video");
    expect(homeSource).toContain("Play intro video");
    expect(homeSource).toContain("onCanPlay");
    expect(homeSource).toContain('controls preload="metadata"');
    expect(homeSource).toContain("10 sec NESCO intro");
  });

  it("keeps a separate fallback image beneath the foreground video", () => {
    expect(homeSource).toContain("hero-fallback");
    expect(homeSource).toContain("hero-media");
  });

  it("includes the uploaded intro video in the hero", () => {
    expect(homeSource).toContain("NescoElevatorIntroWatermark_f4d85fda.mp4");
    expect(homeSource).toContain("hero-video");
    expect(homeSource).toContain("autoPlay muted loop playsInline");
  });

  it("includes corporate-ready detail panels for interior pages", () => {
    expect(homeSource).toContain("detail-aside-panel");
    expect(homeSource).toContain("detail-aside-image");
    expect(homeSource).toContain("detail-aside-points");
    expect(homeSource).toContain("Car Parking System Installation & Services");
  });

  it("includes photo-led homepage interaction blocks", () => {
    expect(homeSource).toContain("home-service-grid");
    expect(homeSource).toContain("home-service-image");
    expect(homeSource).toContain("intro-visual");
    expect(homeSource).toContain("homepage-product-thumb");
    expect(homeSource).toContain("home-service-hover");
  });

  it("includes reference-derived service content, parking solutions, and portfolio details", () => {
    expect(homeSource).toContain("Car Parking System Installation & Services");
    expect(homeSource).toContain("Residential Tower — Andheri West");
    expect(homeSource).toContain("Commercial Complex — BKC");
    expect(homeSource).toContain("Hospital Wing — Borivali");
    expect(homeSource).toContain("service-parking_05a71575.jpg");
    expect(homeSource).toContain("service-escalator_13b252e0.jpg");
  });

  it("includes clickable project profiles with descriptive project content", () => {
    expect(homeSource).toContain("projectProfiles");
    expect(homeSource).toContain("projectRoutes");
    expect(homeSource).toContain("/projects/${index + 1}");
    expect(homeSource).toContain("project-profile-image");
  });
});

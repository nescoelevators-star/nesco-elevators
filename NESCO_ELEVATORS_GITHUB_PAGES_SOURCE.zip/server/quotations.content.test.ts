import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("NESCO quotation template workspace", () => {
  const source = readFileSync(resolve(process.cwd(), "client/src/pages/Quotations.tsx"), "utf8");
  const styles = readFileSync(resolve(process.cwd(), "client/src/quotation.css"), "utf8");

  it("keeps four separate quotation template profiles", () => {
    expect(source).toContain('type TemplateKey = "basic" | "standard" | "advance" | "repair"');
    expect(source).toContain("Basic / Essential AMC");
    expect(source).toContain("Standard AMC");
    expect(source).toContain("Advance Fully Comprehensive AMC");
    expect(source).toContain("Repair / Service / Replacement");
  });

  it("includes the source-derived Standard and Advance component coverage", () => {
    expect(source).toContain("Door Guides (gibs)");
    expect(source).toContain("PCB for LOP Button");
    expect(source).toContain("Brake Coil");
    expect(source).toContain("Over Speed Governor");
    expect(source).toContain("Main and Deflector Sheave");
  });

  it("supports editable components, dynamic BOQ rows, GST and print output", () => {
    expect(source).toContain("Add component");
    expect(source).toContain("Add BOQ row");
    expect(source).toContain("window.print()");
    expect(source).toContain("subtotal");
    expect(source).toContain("gst");
    expect(styles).toContain("@page{size:A4 portrait");
    expect(styles).toContain(".quotation-editor");
    expect(styles).toContain(".quotation-document");
  });

  it("keeps the workspace admin-only and removes generic template wording from the document", () => {
    expect(source).toContain('useAuth({ redirectOnUnauthenticated: true })');
    expect(source).toContain('user.role !== "admin"');
    expect(source).toContain("We are pleased to submit our Standard Annual Maintenance Contract (AMC) quotation");
    expect(source).toContain("We are pleased to submit our quotation for elevator door replacement and associated civil work");
    expect(source).not.toContain("selected NESCO template");
    expect(source).not.toContain("customer-specific details entered above");
  });

  it("supports persistent profiles, quotation history, and agreement generation", () => {
    expect(source).toContain("Save customer");
    expect(source).toContain("Open quotation history");
    expect(source).toContain("Create AMC Agreement");
    expect(source).toContain("trpc.quotations.customers.save.useMutation");
    expect(source).toContain("trpc.quotations.save.useMutation");
    expect(source).toContain("trpc.quotations.createAgreement.useMutation");
  });

  it("provides a public admin sign-in entry point", () => {
    const home = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");
    expect(home).toContain("Admin sign in");
    expect(home).toContain("startLogin()");
  });

  it("supports editable contract amount words and complete terms sections", () => {
    expect(source).toContain("Contract Amount in Words");
    expect(source).toContain("amountInWords");
    expect(source).toContain("Emergency / Entrapment Support");
    expect(source).toContain("External Factors / Warranty Void");
    expect(source).toContain("TERMS & CONDITIONS — REPAIR / SERVICE / REPLACEMENT");
    expect(source).toContain("repairTerms.map");
    expect(styles).toContain("document-header-brand");
  });
});

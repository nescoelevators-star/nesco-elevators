import { describe, expect, it } from "vitest";
import { NESCO_FORM_ENDPOINT, NESCO_NOTIFICATION_EMAIL, NESCO_WHATSAPP_EVENT, NESCO_WHATSAPP_URL } from "../shared/const";

describe("NESCO enquiry integration", () => {
  it("uses the approved Formspree endpoint and official notification email", () => {
    expect(NESCO_FORM_ENDPOINT).toBe("https://formspree.io/f/xbglddvy");
    expect(NESCO_NOTIFICATION_EMAIL).toBe("nescoelevators@outlook.in");
    expect(NESCO_WHATSAPP_URL).toContain("wa.me/919833459273");
    expect(NESCO_WHATSAPP_EVENT).toBe("whatsapp_click");
  });
});

import { Link } from "wouter";
import { ArrowUpRight, Check, Download, MessageCircle, Printer } from "lucide-react";
import { NESCO_WHATSAPP_URL } from "@shared/const";

const logo = "https://nescolift-cnc2dnkj.manus.space/manus-storage/nesco-logo_f843e3f6.png";
const hero = "https://nescolift-cnc2dnkj.manus.space/manus-storage/nesco-catalogue_befcb4c2.jpg";
const service = "https://nescolift-cnc2dnkj.manus.space/manus-storage/nesco-service_7d1c8a36.jpg";

const products = [
  "Passenger Elevators",
  "Commercial Lifts",
  "Home & Residential Elevators",
  "Hospital & Stretcher Elevators",
  "Capsule & Panoramic Elevators",
  "Goods & Freight Elevators",
  "Car Elevators",
  "Dumbwaiter Elevators",
];

const services = [
  ["New lift installation", "Planning, installation, erection, testing and commissioning where applicable to the confirmed project scope."],
  ["AMC and preventive maintenance", "Systematic inspections, preventive servicing, troubleshooting, component assessment and targeted repairs."],
  ["Repairs and breakdown support", "Structured fault finding, relevant component checks and targeted repair planning."],
  ["Technical consultancy", "Practical guidance for planning, evaluating and improving vertical mobility systems."],
  ["Technical site survey", "Review of existing equipment, site conditions, usage patterns and possible lift requirements."],
  ["Electrical solutions", "Electrical works and support related to the confirmed elevator or building requirement."],
];

const modernization = [
  "Control systems and V3F drives",
  "Safety and control components",
  "LOP / COP panels",
  "Door sensors and operators",
  "Lift ropes",
  "Cabin-related works",
];

const industries = ["Residential buildings", "Commercial offices", "Hospitals", "Hotels", "Retail properties", "Industrial facilities", "Institutional buildings"];
const approvedStatement = "NESCO ELEVATORS – An MSME-registered and government-approved company offering complete elevator and electrical solutions, including installation, repair, maintenance, modernization, erection, and technical consultancy.";

function SectionHead({ number, label }: { number: string; label: string }) {
  return <div className="catalogue-page-head"><span>{number} / NESCO ELEVATORS</span><span>{label}</span></div>;
}

export default function Catalogue() {
  return <div className="catalogue-shell">
    <div className="catalogue-toolbar"><Link href="/" className="catalogue-back">← Back to website</Link><div className="catalogue-actions"><a href={NESCO_WHATSAPP_URL} target="_blank" rel="noreferrer"><MessageCircle size={15} /> Enquire on WhatsApp</a><button onClick={() => window.print()}><Printer size={15} /> Print / save as PDF</button></div></div>
    <article className="catalogue-document">
      <section className="catalogue-cover catalogue-page"><div className="catalogue-brand-lockup"><img src={logo} alt="NESCO Elevators" /><strong>NESCO Elevators</strong></div><div className="catalogue-cover-title"><span>Complete vertical mobility solutions</span><h1>Engineering every<br /><em>vertical journey.</em></h1><p>Complete company, product & services catalogue · 2026</p></div><div className="catalogue-cover-image" style={{ backgroundImage: `url(${hero})` }} /><div className="catalogue-cover-foot"><span>Safe Spaces. Higher Possibilities.</span><span>nescoelevators@outlook.in</span></div></section>

      <section className="catalogue-page catalogue-intro"><SectionHead number="02" label="Company profile" /><div className="catalogue-intro-grid"><div><span className="catalogue-kicker">About NESCO Elevators</span><h2>Moving people.<br /><em>Elevating possibilities.</em></h2></div><div><p className="catalogue-lead">A lift is more than a machine between floors. It is a daily interface with your building, your people and your plans.</p><p>{approvedStatement}</p><p>NESCO Elevators brings an engineering-led approach to complete vertical mobility solutions, shaped around the building, the lift and the people who use it.</p><div className="catalogue-note"><Check size={15} /> Clear scope. Practical guidance. Ongoing support.</div></div></div><div className="catalogue-large-image" style={{ backgroundImage: `url(${service})` }} /></section>

      <section className="catalogue-page catalogue-content"><SectionHead number="03" label="Products & solutions" /><div className="catalogue-page-title"><span className="catalogue-kicker">Product range</span><h2>Solutions built around<br /><em>the building.</em></h2><p>Explore the elevator categories NESCO can discuss for residential, commercial, healthcare, hospitality, retail, industrial and institutional settings. Final suitability, specification, availability and scope are confirmed for each project.</p></div><div className="catalogue-product-grid">{products.map((product, index) => <div key={product}><span>0{index + 1}</span><strong>{product}</strong><ArrowUpRight size={15} /></div>)}</div><div className="catalogue-scope-note"><strong>Project scope</strong><span>Product selection follows site conditions, intended use, traffic requirements, design context and technical evaluation.</span></div></section>

      <section className="catalogue-page catalogue-content"><SectionHead number="04" label="Services" /><div className="catalogue-page-title"><span className="catalogue-kicker">Complete support</span><h2>Support across<br /><em>the lift lifecycle.</em></h2><p>From first conversation to ongoing care, NESCO Elevators helps building owners, societies, developers, architects and facility teams move toward a clear next step.</p></div><div className="catalogue-service-grid">{services.map(([title, description], index) => <div className="catalogue-service-card" key={title}><span>0{index + 1}</span><h3>{title}</h3><p>{description}</p></div>)}</div></section>

      <section className="catalogue-page catalogue-content"><SectionHead number="05" label="Modernization & relevant details" /><div className="catalogue-page-title"><span className="catalogue-kicker">Modernization</span><h2>Make existing<br /><em>systems work harder.</em></h2><p>Modernization is a project-specific exercise. NESCO assesses the current system, identifies applicable upgrades and defines a practical path for supply, installation, testing and commissioning where applicable.</p></div><div className="catalogue-detail-columns"><div><h3>Possible modernization components</h3><ul>{modernization.map((item) => <li key={item}><Check size={15} />{item}</li>)}</ul></div><div><h3>How we begin</h3><ol><li><strong>Understand</strong><span>Review the building, lift and operating context.</span></li><li><strong>Assess</strong><span>Consider existing equipment and site conditions.</span></li><li><strong>Recommend</strong><span>Define an appropriate, proportionate next step.</span></li><li><strong>Support</strong><span>Keep communication and agreed scope visible.</span></li></ol></div></div><div className="catalogue-industries"><strong>Relevant settings</strong><span>{industries.join(" · ")}</span></div></section>

      <section className="catalogue-page catalogue-contact"><div className="catalogue-brand-lockup"><img src={logo} alt="NESCO Elevators" /><strong>NESCO Elevators</strong></div><span className="catalogue-kicker">Your elevator. Our ongoing commitment.</span><h2>Let’s talk about<br /><em>the next floor.</em></h2><div className="catalogue-contact-grid"><div><strong>Call</strong><a href="tel:+919833459273">+91 98334 59273</a><a href="tel:+919820567419">+91 98205 67419</a></div><div><strong>WhatsApp</strong><a href={NESCO_WHATSAPP_URL} target="_blank" rel="noreferrer">Chat with NESCO</a></div><div><strong>Email</strong><a href="mailto:nescoelevators@outlook.in">nescoelevators@outlook.in</a></div><div><strong>Office</strong><span>Sonam Saraswati Apartment, Office No. 17, Golden Nest,<br />Near Balaji Hospital, Mira Road (East),<br />Thane – 401107, Maharashtra, India.</span></div></div><p className="catalogue-fine">{approvedStatement}</p><p className="catalogue-fine">Use the Print / save as PDF button above to download this complete catalogue from the portal.</p></section>
    </article>
  </div>;
}

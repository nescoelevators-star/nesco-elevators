import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { NESCO_FORM_ENDPOINT, NESCO_WHATSAPP_EVENT, NESCO_WHATSAPP_URL } from "@shared/const";
import Catalogue from "./Catalogue";
import {
  ArrowUpRight,
  Check,
  ChevronDown,
  ChevronRight,
  ClipboardCheck,
  Cog,
  Factory,
  Building2,
  Hospital,
  Hotel,
  House,
  Landmark,
  ShoppingBag,
  Gauge,
  Headphones,
  Menu,
  MessageCircle,
  MoveUpRight,
  Phone,
  Pause,
  Play,
  Quote,
  ScanLine,
  ShieldCheck,
  Sparkles,
  Wrench,
  X,
} from "lucide-react";

const trackWhatsappClick = () => {
  try {
    const analyticsWindow = window as Window & { dataLayer?: unknown[]; gtag?: (...args: unknown[]) => void };
    const payload = { event: NESCO_WHATSAPP_EVENT, phone: "+91 98334 59273" };
    analyticsWindow.dataLayer?.push(payload);
    analyticsWindow.gtag?.("event", NESCO_WHATSAPP_EVENT, { phone_number: "+919833459273" });
  } catch {
    // Analytics must never prevent a visitor from opening WhatsApp.
  }
};

const ASSETS = {
  logo: "https://nescolift-cnc2dnkj.manus.space/manus-storage/nesco-logo_f843e3f6.png",
  hero: "https://nescolift-cnc2dnkj.manus.space/manus-storage/ref-hero_d41beac7.jpg",
  service: "https://nescolift-cnc2dnkj.manus.space/manus-storage/service-repair_a06ebc7f.jpg",
  catalogue: "https://nescolift-cnc2dnkj.manus.space/manus-storage/service-modernization_0f1d86e6.jpg",
  amc: "https://nescolift-cnc2dnkj.manus.space/manus-storage/service-amc_b8e2e696.jpg",
  repair: "https://nescolift-cnc2dnkj.manus.space/manus-storage/service-repair_a06ebc7f.jpg",
  parking: "https://nescolift-cnc2dnkj.manus.space/manus-storage/service-parking_05a71575.jpg",
  modernization: "https://nescolift-cnc2dnkj.manus.space/manus-storage/service-modernization_0f1d86e6.jpg",
  escalator: "https://nescolift-cnc2dnkj.manus.space/manus-storage/service-escalator_13b252e0.jpg",
  digital: "https://nescolift-cnc2dnkj.manus.space/manus-storage/digital-tools_fe0739b6.jpg",
};

const navItems = [
  ["About", "/about"],
  ["Products", "/products"],
  ["Services", "/services"],
  ["Modernization", "/modernization"],
  ["Industries", "/industries"],
];

const services = [
  { no: "01", title: "New Lift Installation", desc: "From planning to commissioning, coordinate a lift installation around your building, users and operating needs.", icon: MoveUpRight, path: "/services/new-installation" },
  { no: "02", title: "AMC & Preventive Maintenance", desc: "Systematic inspections, preventive servicing, troubleshooting and targeted repairs for dependable operation.", icon: ShieldCheck, path: "/services/maintenance" },
  { no: "03", title: "Lift Modernization & Upgrades", desc: "Refresh applicable control, drive, safety, door and cabin-related systems without losing sight of the whole lift.", icon: Cog, path: "/services/modernization" },
  { no: "04", title: "Repairs & Breakdown Support", desc: "Structured fault finding and component assessment to help move from disruption to a clear repair plan.", icon: Wrench, path: "/services/repairs" },
  { no: "05", title: "Lift Consultancy", desc: "Independent technical guidance for planning, evaluating and improving vertical mobility systems.", icon: Headphones, path: "/services/consultancy" },
  { no: "06", title: "Technical Site Survey", desc: "A practical view of site conditions, existing equipment, usage patterns and potential lift requirements.", icon: ScanLine, path: "/services/site-survey" },
];

const serviceCards: Array<[string, string, string, string, string]> = [
  ["01", "Elevator AMC", "Scheduled inspections, preventive servicing, priority response and spare-parts support to keep elevators operating reliably.", "/services/maintenance", ASSETS.amc],
  ["02", "Elevator Repair & Services", "Professional fault diagnosis and repair support for elevator systems, with safety checks and practical response planning.", "/services/repairs", ASSETS.repair],
  ["03", "Elevator Installation", "Turnkey lift installation from site assessment and planning through shaft coordination, commissioning and handover.", "/services/new-installation", ASSETS.hero],
  ["04", "Car Parking System Installation & Services", "Automated and mechanical parking solutions for residential and commercial projects, including installation, commissioning and maintenance.", "/services/car-parking", ASSETS.parking],
  ["05", "Modernization", "Upgrade controls, drives, safety systems and cabin environments to improve performance, efficiency and everyday experience.", "/services/modernization", ASSETS.modernization],
  ["06", "Technical Site Survey & Consultancy", "Review site conditions, existing equipment, usage patterns and project goals before defining the right vertical mobility path.", "/services/site-survey", ASSETS.digital],
  ["07", "Electrical Solutions", "Electrical works and technical support related to elevator systems and building requirements.", "/services/electrical-solutions", ASSETS.repair],
];
const products = [
  "Passenger Elevators",
  "Commercial Lifts",
  "Home & Residential Elevators",
  "Hospital & Stretcher Elevators",
  "Capsule & Panoramic Elevators",
  "Goods & Freight Elevators",
  "Car Elevators",
  "Dumbwaiter Elevators",
];

const productRoutes: Record<string, string> = {
  "Passenger Elevators": "/products/passenger-elevators",
  "Commercial Lifts": "/products/commercial-lifts",
  "Home & Residential Elevators": "/products/home-residential-elevators",
  "Hospital & Stretcher Elevators": "/products/hospital-stretcher-elevators",
  "Capsule & Panoramic Elevators": "/products/capsule-panoramic-elevators",
  "Goods & Freight Elevators": "/products/goods-freight-elevators",
  "Car Elevators": "/products/car-elevators",
  "Dumbwaiter Elevators": "/products/dumbwaiter-elevators",
};

const productCards: Array<[string, string, string]> = [
  ["Passenger Elevators", "Everyday passenger movement shaped around the building.", ASSETS.hero],
  ["Commercial Lifts", "Built for offices, retail, mixed-use and business environments.", ASSETS.modernization],
  ["Home & Residential Elevators", "Vertical mobility for homes, apartments and societies.", ASSETS.repair],
  ["Hospital & Stretcher Elevators", "Movement planned around healthcare access and operations.", ASSETS.amc],
  ["Capsule & Panoramic Elevators", "A visible lift concept that becomes part of the architecture.", ASSETS.digital],
  ["Goods & Freight Elevators", "Move goods and materials around the operating requirement.", ASSETS.parking],
  ["Car Elevators", "Vertical vehicle movement for residential and commercial parking.", ASSETS.parking],
  ["Dumbwaiter Elevators", "Small-format service movement for practical building needs.", ASSETS.escalator],
];

const industries = ["Residential buildings", "Commercial offices", "Hospitals", "Hotels", "Retail properties", "Industrial facilities", "Institutional buildings"];
const industryTiles: Array<[string, string, React.ElementType]> = [
  ["Residential buildings", "Homes, apartments and societies", House],
  ["Commercial offices", "Workplaces and mixed-use buildings", Building2],
  ["Hospitals", "Healthcare and stretcher movement", Hospital],
  ["Hotels", "Hospitality and guest experience", Hotel],
  ["Retail properties", "Stores, malls and customer flow", ShoppingBag],
  ["Industrial facilities", "Goods, freight and operational movement", Factory],
  ["Institutional buildings", "Public, educational and civic settings", Landmark],
];
const projectProfiles: Array<[string, string, string, string]> = [
  ["Residential Tower — Andheri West", "Residential · Andheri West, Mumbai", "Complete elevator installation for a 14-storey residential tower. Delivered 4 high-speed passenger elevators with advanced safety features and energy-efficient drives. Project metrics: 4 passenger elevators, 14 floors, 1200 kg capacity and 2.5 m/s speed.", ASSETS.hero],
  ["Commercial Complex — BKC", "Commercial · Bandra Kurla Complex, Mumbai", "Installation and AMC support for a premium commercial complex. Deployed 6 elevators with smart destination dispatch technology and premium interior finishes. Project metrics: 6 passenger elevators, 22 floors, 1600 kg capacity and smart dispatch.", ASSETS.modernization],
  ["Luxury Villa — Juhu", "Residential · Juhu, Mumbai", "Custom home elevator installation for a luxury private villa. A compact shaftless design with panoramic glass cabin and quiet operation. Project metrics: 1 home elevator, 3 floors, 400 kg capacity and glass cabin.", ASSETS.repair],
  ["Shopping Mall — Malad", "Commercial · Malad West, Mumbai", "Complete vertical transportation solution for a shopping mall, including passenger elevators and escalators, supported by an ongoing AMC program. Project metrics: 3 elevators, 2 escalators, 5 floors, heavy-duty operation and AMC support.", ASSETS.escalator],
  ["Hospital Wing — Borivali", "Healthcare · Borivali East, Mumbai", "Hospital-grade stretcher elevator installation for a new hospital wing, with anti-vibration technology and emergency power backup systems. Project metrics: 3 stretcher elevators, 8 floors, 2500 kg capacity and emergency backup.", ASSETS.amc],
  ["Society Complex — Kandivali", "Residential · Kandivali East, Mumbai", "Multi-building residential society project with 8 elevators across 3 towers, including installation, commissioning and a 5-year AMC program. Project metrics: 8 passenger elevators, 3 towers, 1000 kg capacity and 5-year AMC.", ASSETS.digital],
];
const projectRoutes: Record<string, string> = Object.fromEntries(projectProfiles.map(([title], index) => [title, `/projects/${index + 1}`]));
const projectPageData: Record<string, { eyebrow: string; title: string; intro: string; category: string; image: string; items: string[] }> = Object.fromEntries(projectProfiles.map(([title, category, desc, image], index) => [`/projects/${index + 1}`, { eyebrow: "Project profile", title, intro: desc, category, image, items: ["Project name and site context", "Lift category and project scope", "Project imagery and technical notes", "Completion or service status"] }]));

const basePageCopy: Record<string, { eyebrow: string; title: string; intro: string; image?: string }> = {
  "/about": { eyebrow: "About NESCO", title: "Engineering every vertical journey.", intro: "NESCO Elevators is a vertical mobility solutions company focused on the practical work behind safe, usable and maintainable lift systems. Our approach connects site realities with clear technical decisions.", image: ASSETS.catalogue },
  "/products": { eyebrow: "Products & solutions", title: "A lift solution starts with the building.", intro: "Explore a flexible set of elevator categories. Final suitability, scope and availability are confirmed against project requirements, site conditions and technical evaluation.", image: ASSETS.catalogue },
  "/services": { eyebrow: "Our services", title: "Support for the full lift lifecycle.", intro: "From a new installation to a careful repair, NESCO brings structured technical thinking to every stage of the lift journey.", image: ASSETS.service },
  "/modernization": { eyebrow: "Modernization", title: "Make an existing lift ready for what is next.", intro: "Modernization is a project-specific exercise. We assess the current system, identify applicable upgrades and define a practical path for supply, installation, testing and commissioning where applicable.", image: ASSETS.service },
  "/maintenance": { eyebrow: "AMC & maintenance", title: "Preventive care, made systematic.", intro: "Maintenance can include systematic inspections, preventive servicing, troubleshooting, component assessment and targeted repairs. The actual scope is confirmed for each lift and agreement.", image: ASSETS.service },
  "/repairs": { eyebrow: "Repairs & breakdown support", title: "Clear thinking when a lift stops.", intro: "A structured repair process begins with understanding the fault, checking relevant components and communicating a targeted repair path. No one-size-fits-all promise—just practical engineering.", image: ASSETS.service },
  "/consultancy": { eyebrow: "Consultancy & site survey", title: "Better decisions begin on site.", intro: "Use technical consultancy and site survey inputs to understand existing equipment, constraints, usage patterns and possible lift requirements before committing to a scope.", image: ASSETS.catalogue },
  "/industries": { eyebrow: "Industries", title: "Vertical mobility for real-world settings.", intro: "Every building has a different rhythm. NESCO’s industry framework helps teams discuss needs clearly across residential, commercial, healthcare, hospitality, retail, industrial and institutional contexts.", image: ASSETS.hero },
  "/projects": { eyebrow: "Projects", title: "A portfolio built with the right details.", intro: "Explore NESCO project categories across residential, commercial, healthcare, modernization, maintenance and industrial applications.", image: ASSETS.hero },
  "/faq": { eyebrow: "FAQ", title: "Straight answers to practical questions.", intro: "Use this space to make scope, process and next steps easier to understand for building owners, societies, developers, architects and facility teams.", image: ASSETS.catalogue },
  "/contact": { eyebrow: "Contact NESCO", title: "Your elevator. Our ongoing commitment.", intro: "Share the basics of your requirement. The right conversation starts with the building, the lift and the outcome you need.", image: ASSETS.hero },
  "/privacy": { eyebrow: "Privacy policy", title: "A clear approach to your information.", intro: "NESCO Elevators uses enquiry information only to respond to your request, understand your lift requirement and provide relevant technical or commercial communication. We do not sell or publish your contact information.", image: ASSETS.catalogue },
  "/terms": { eyebrow: "Terms & conditions", title: "The working terms, made clear.", intro: "All services, specifications, pricing, timelines and project scope are discussed and agreed for the individual requirement. Site conditions, technical assessment and written confirmation govern the final scope of work.", image: ASSETS.catalogue },
};


const servicePageData: Record<string, { eyebrow: string; title: string; intro: string; items: string[] }> = {
  "/services/new-installation": { eyebrow: "New lift installation", title: "A clear start for a new lift.", intro: "Coordinate a new lift journey around the building, intended use, users and operating needs.", items: ["Planning and requirement discussion", "Site and building context review", "Installation and erection where applicable", "Testing and commissioning where applicable"] },
  "/services/maintenance": { eyebrow: "AMC & preventive maintenance", title: "Preventive care, made systematic.", intro: "Build a maintenance approach around the lift, the agreement and the building’s operating needs.", items: ["Systematic inspections", "Preventive servicing", "Troubleshooting and component assessment", "Targeted repairs and service review"] },
  "/services/modernization": { eyebrow: "Lift modernization", title: "Make an existing lift ready for what is next.", intro: "Assess the current system, identify applicable upgrades and define a practical modernization path.", items: ["Control systems and V3F drives", "Safety and control components", "LOP / COP panels", "Door sensors, lift ropes and cabin-related works"] },
  "/services/repairs": { eyebrow: "Repairs & breakdown support", title: "Clear thinking when a lift stops.", intro: "Move from disruption toward a clearer repair plan with structured fault finding and relevant component checks.", items: ["Understand the reported fault", "Check relevant lift components", "Assess repair requirements", "Communicate the targeted next step"] },
  "/services/consultancy": { eyebrow: "Lift consultancy & site survey", title: "Better decisions begin on site.", intro: "Use technical consultancy and site survey inputs to understand existing equipment, constraints, usage patterns and possible requirements.", items: ["Existing equipment review", "Site condition and usage discussion", "Requirement and option planning", "Technical recommendations for the next step"] },
  "/services/site-survey": { eyebrow: "Technical site survey", title: "See the building before shaping the scope.", intro: "A practical site survey brings existing equipment, site conditions, usage patterns and possible lift requirements into focus.", items: ["Review site access and conditions", "Understand existing lift equipment", "Discuss usage and operating patterns", "Record inputs for the next project decision"] },
  "/services/car-parking": { eyebrow: "Car parking systems", title: "Make every parking level work harder.", intro: "Plan automated and mechanical car parking systems around the available footprint, access pattern, vehicle flow and operating needs.", items: ["Automated parking system planning", "Mechanical stacker and platform coordination", "Installation and commissioning", "Maintenance and support planning"] },
  "/services/electrical-solutions": { eyebrow: "Electrical solutions", title: "Electrical support around the requirement.", intro: "Discuss electrical works and technical support related to the confirmed elevator or building requirement.", items: ["Electrical requirement discussion", "Relevant system and component review", "Coordination with confirmed lift scope", "Technical support where applicable"] },
};

const productPageData: Record<string, { eyebrow: string; title: string; intro: string; items: string[] }> = {
  "/products/passenger-elevators": { eyebrow: "Passenger elevators", title: "Everyday movement, considered.", intro: "Passenger elevator discussions shaped around building use, traffic context, user experience and site conditions.", items: ["Residential and commercial applications", "Passenger flow and intended use discussion", "Cabin, access and control considerations", "Suitability confirmed against project requirements"] },
  "/products/commercial-lifts": { eyebrow: "Commercial lifts", title: "Built for commercial movement.", intro: "Commercial lift solutions for offices, retail, mixed-use and business environments, subject to project evaluation.", items: ["Commercial building applications", "Passenger and service movement considerations", "Traffic, access and operating context review", "Product suitability confirmed for each project"] },
  "/products/home-residential-elevators": { eyebrow: "Home & residential elevators", title: "Vertical mobility for residential life.", intro: "Explore residential lift requirements around the home, apartment building, users and available space.", items: ["Home and residential applications", "Space and access considerations", "User comfort and operating context", "Site suitability review"] },
  "/products/hospital-stretcher-elevators": { eyebrow: "Hospital & stretcher elevators", title: "Movement where every detail matters.", intro: "Discuss hospital and stretcher elevator needs around building operations, access, users and site conditions.", items: ["Healthcare and institutional applications", "Stretcher and user movement context", "Access and operating requirements", "Project-specific technical evaluation"] },
  "/products/capsule-panoramic-elevators": { eyebrow: "Capsule & panoramic elevators", title: "A lift that becomes part of the architecture.", intro: "Consider capsule and panoramic lift concepts for spaces where visibility, design intent and user experience matter.", items: ["Architectural and hospitality applications", "Visibility and design context", "Site and installation considerations", "Final suitability confirmed for the project"] },
  "/products/goods-freight-elevators": { eyebrow: "Goods & freight elevators", title: "Move what the building needs.", intro: "Goods and freight lift discussions shaped around loads, movement patterns, access and operational requirements.", items: ["Industrial, retail and service applications", "Goods movement and loading context", "Usage and access requirements", "Capacity and suitability confirmed per project"] },
  "/products/car-elevators": { eyebrow: "Car elevators", title: "Vertical movement for vehicles.", intro: "Explore car elevator requirements around site access, vehicle movement, space planning and operating context.", items: ["Residential and commercial parking applications", "Vehicle access and movement discussion", "Space and site condition review", "Project-specific solution planning"] },
  "/products/dumbwaiter-elevators": { eyebrow: "Dumbwaiter elevators", title: "Small-format movement, thoughtfully planned.", intro: "Dumbwaiter lift discussions for service movement in hospitality, healthcare, residential and commercial settings.", items: ["Service and material movement", "Kitchen, hospitality and institutional applications", "Space and access considerations", "Suitability confirmed against the brief"] },
};

const pageCopy = { ...basePageCopy, ...Object.fromEntries(Object.entries(projectPageData).map(([path, data]) => [path, { eyebrow: data.eyebrow, title: data.title, intro: data.intro, image: data.image }])), ...Object.fromEntries(Object.entries(servicePageData).map(([path, data]) => [path, { eyebrow: data.eyebrow, title: data.title, intro: data.intro, image: ASSETS.service }])), ...Object.fromEntries(Object.entries(productPageData).map(([path, data]) => [path, { eyebrow: data.eyebrow, title: data.title, intro: data.intro, image: ASSETS.catalogue }])) };

function Logo({ compact = false }: { compact?: boolean }) {
  return <span className={compact ? "logo-lockup logo-lockup-compact" : "logo-lockup"}><img src={ASSETS.logo} alt="NESCO Elevators — Safe Spaces. Higher Possibilities." className={compact ? "h-8 w-auto object-contain" : "h-11 w-auto object-contain"} /><span className="logo-name">NESCO Elevators</span></span>;
}

function Header() {
  const [open, setOpen] = useState(false);
  const user = null;
  return <header className="site-header">
    <div className="container header-inner">
      <Link href="/" className="brand-link" onClick={() => setOpen(false)}><Logo /></Link>
      <nav className={open ? "main-nav is-open" : "main-nav"} aria-label="Primary navigation">
        {navItems.map(([label, path]) => <Link key={path} href={path} onClick={() => setOpen(false)}>{label}</Link>)}
        <Link href="/projects" onClick={() => setOpen(false)}>Projects</Link>
        <Link href="/faq" onClick={() => setOpen(false)}>FAQ</Link>
      </nav>
      <div className="header-actions">
        <a className="phone-link" href="tel:+919833459273" aria-label="Call NESCO Elevators"><Phone size={17} /></a><a className="whatsapp-link" href={NESCO_WHATSAPP_URL} target="_blank" rel="noreferrer" onClick={trackWhatsappClick}><MessageCircle size={16} /> <span>WhatsApp</span></a><Link className="header-quotation-link" href="/contact" onClick={() => setOpen(false)}>Request a Quote</Link>
        <Link className="header-cta" href="/contact">Start a conversation <ArrowUpRight size={16} /></Link>
        <button className="menu-button" aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
      </div>
    </div>
  </header>;
}

function Footer() {
  const user = null;
  return <footer className="site-footer">
    <div className="container footer-grid">
      <div><Logo compact /><p className="footer-note">Engineering Every Vertical Journey.<br />Safe Spaces. Higher Possibilities.</p></div>
      <div><p className="footer-label">Explore</p><Link href="/products">Products & solutions</Link><Link href="/services">Services</Link><Link href="/maintenance">AMC & maintenance</Link><Link href="/projects">Projects</Link><Link href="/catalogue">Download catalogue</Link><Link href="/contact">Request a Quote</Link></div>
      <div><p className="footer-label">Talk to us</p><a href="tel:+919833459273">+91 98334 59273</a><a href="tel:+919820567419">+91 98205 67419</a><a href={NESCO_WHATSAPP_URL} target="_blank" rel="noreferrer" onClick={trackWhatsappClick}>WhatsApp NESCO</a><a href="mailto:nescoelevators@outlook.in">nescoelevators@outlook.in</a></div>
      <div><p className="footer-label">Legal</p><Link href="/privacy">Privacy policy</Link><Link href="/terms">Terms & conditions</Link><address className="footer-address">NESCO ELEVATORS<br />Sonam Saraswati Apartment, Office No. 17, Golden Nest,<br />Near Balaji Hospital, Mira Road (East),<br />Thane – 401107, Maharashtra, India.</address></div>
    </div>
    <div className="container footer-bottom"><span>© 2026 NESCO Elevators. All rights reserved.</span><span>Complete Vertical Mobility Solutions</span></div>
  </footer>;
}

function ButtonLink({ href, children, muted = false }: { href: string; children: React.ReactNode; muted?: boolean }) {
  return <Link href={href} className={muted ? "button-link muted" : "button-link"}>{children}<ArrowUpRight size={16} /></Link>;
}

function WhyChooseNesco() {
  const reasons = [
    ["01", "Approved company", "NESCO Elevators is an MSME-registered and government-approved company."],
    ["02", "Complete solutions", "Elevator and electrical solutions for installation, repair, maintenance, modernization and erection."],
    ["03", "Technical guidance", "Technical consultancy and clear planning to help teams make practical lift decisions."],
    ["04", "Lifecycle support", "A structured approach from site understanding and installation through ongoing care."],
  ];
  return <section className="why-section section-pad" id="why-nesco">
    <div className="container">
      <div className="section-kicker">Why choose NESCO / 03</div>
      <div className="section-heading split"><div><h2>Engineering that keeps<br /><em>the brief in view.</em></h2></div><p>NESCO ELEVATORS offers complete elevator and electrical solutions, including installation, repair, maintenance, modernization, erection and technical consultancy.</p></div>
      <div className="why-grid">{reasons.map(([no, title, desc]) => <div className="why-card" key={no}><span>{no}</span><Check size={20} /><h3>{title}</h3><p>{desc}</p></div>)}</div>
    </div>
  </section>;
}

function HomePage() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoPlaying, setVideoPlaying] = useState(true);
  const toggleVideo = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      video.play().then(() => setVideoPlaying(true)).catch(() => setVideoPlaying(false));
    } else {
      video.pause();
      setVideoPlaying(false);
    }
  };
  return <>
    <section className="hero-section"><div className="hero-fallback" aria-hidden="true" /><div className="hero-scrim" /><div className="hero-media"><video ref={videoRef} className="hero-video" autoPlay muted loop playsInline controls preload="metadata" poster="https://nescolift-cnc2dnkj.manus.space/manus-storage/nesco-hero_be5132ea.jpg" aria-label="NESCO Elevators introduction video" onPlay={() => setVideoPlaying(true)} onPause={() => setVideoPlaying(false)} onCanPlay={() => { void videoRef.current?.play().catch(() => setVideoPlaying(false)); }}><source src="https://nescolift-cnc2dnkj.manus.space/manus-storage/NescoElevatorIntroWatermark_f4d85fda.mp4" type="video/mp4" /></video></div><div className="container hero-content"><div className="hero-copy"><div className="eyebrow light"><span className="eyebrow-dot" /> Complete vertical mobility solutions</div><h1>Moving people.<br /><em>Elevating possibilities.</em></h1><p>Engineering-led elevator installation, modernization, maintenance and support for the spaces where people live, work and thrive.</p><div className="hero-actions"><ButtonLink href="/contact">Plan your lift journey</ButtonLink><Link className="text-link light-link" href="/services">Explore services <ChevronRight size={16} /></Link><button className="hero-video-toggle" type="button" onClick={toggleVideo} aria-label={videoPlaying ? "Pause intro video" : "Play intro video"}><span>{videoPlaying ? <Pause size={13} /> : <Play size={13} />}</span>{videoPlaying ? "Pause intro" : "Play intro"}</button><span className="hero-video-note">10 sec NESCO intro</span></div></div><div className="hero-side-note"><span>01 / 04</span><span>Designed for the way buildings move.</span></div></div><div className="hero-bottom"><div className="container hero-metrics"><span>01 <b>Engineering first</b></span><span>02 <b>Lifecycle thinking</b></span><span>03 <b>Clear communication</b></span><span className="scroll-cue">Scroll to explore <ChevronDown size={16} /></span></div></div></section>
    <section className="intro-section section-pad"><div className="container intro-grid"><div className="section-kicker">NESCO / 01</div><div className="intro-copy"><h2>Safe spaces.<br /><em>Higher possibilities.</em></h2><p className="lead">A lift is more than a machine between floors. It is a daily interface with your building, your people and your plans. NESCO Elevators brings the technical detail into focus—so every decision can move forward with confidence.</p><ButtonLink href="/about" muted>Discover NESCO</ButtonLink></div><Link href="/about" className="intro-visual"><div className="intro-visual-image" style={{ backgroundImage: `url(${ASSETS.digital})` }} /><div className="intro-visual-caption"><span>01 / 04</span><strong>Designed for the way buildings move.</strong><ArrowUpRight size={17} /></div></Link></div></section>
    <section className="service-section section-pad"><div className="container"><div className="section-kicker">What we do / 02</div><div className="section-heading split"><h2>One partner for<br /><em>every lift stage.</em></h2><p>From a first site survey to ongoing care, our services are shaped around the lift in front of us—not a generic checklist.</p></div><div className="home-service-grid">{serviceCards.map(([no, title, desc, servicePath, image]) => <Link href={servicePath} key={no} className="home-service-card"><div className="home-service-image" style={{ backgroundImage: `url(${image})` }}><span>SERVICE {no}</span><div className="home-service-hover"><ArrowUpRight size={20} /></div></div><div className="home-service-content"><div><h3>{title}</h3><p>{desc}</p></div><ArrowUpRight className="home-service-arrow" size={17} /></div></Link>)}</div></div></section>
    <section className="split-feature"><div className="feature-image" style={{ backgroundImage: `url(${ASSETS.service})` }} /><div className="feature-copy"><div className="section-kicker light">Modernization / 03</div><h2>Make existing<br /><em>systems work harder.</em></h2><p>Control systems, V3F drives, safety and control components, LOP/COP panels, door sensors, lift ropes and cabin-related works may all form part of a project-specific modernization scope.</p><ButtonLink href="/modernization">See what’s possible</ButtonLink></div></section>
    <section className="product-section section-pad"><div className="container product-layout"><div className="product-intro"><div className="section-kicker">Solutions / 04</div><h2>Built around<br /><em>the brief.</em></h2><p className="lead small">Explore lift categories shaped around residential, commercial, healthcare, parking and operational needs.</p><ButtonLink href="/products" muted>View product categories</ButtonLink></div><div className="homepage-product-list">{productCards.map(([product, desc, image], index) => <Link href={productRoutes[product] || "/products"} key={product} className="homepage-product-row"><div className="homepage-product-thumb" style={{ backgroundImage: `url(${image})` }}><span>0{index + 1}</span></div><div className="homepage-product-copy"><h3>{product}</h3><p>{desc}</p></div><ArrowUpRight size={17} /></Link>)}</div></div></section>
    <WhyChooseNesco />
    <section className="contact-band"><div className="container contact-band-inner"><div><div className="section-kicker light">Start a conversation / 05</div><h2>Your elevator.<br /><em>Our ongoing commitment.</em></h2></div><ButtonLink href="/contact">Talk to NESCO</ButtonLink></div></section>
  </>;
}

function DetailPage({ path }: { path: string }) {
  const copy = pageCopy[path] || pageCopy["/about"];
  const isFaq = path === "/faq";
  const isContact = path === "/contact";
  const isServices = path === "/services";
  return <>
    <section className="page-hero"><div className="page-hero-image" style={{ backgroundImage: `url(${copy.image || ASSETS.catalogue})` }} /><div className="page-hero-overlay" /><div className="container page-hero-content"><div className="eyebrow light"><span className="eyebrow-dot" /> {copy.eyebrow}</div><h1>{copy.title}</h1><p>{copy.intro}</p></div></section>
    <section className="detail-section section-pad"><div className="container detail-grid"><aside className="detail-aside-panel"><div className="detail-aside-image" style={{ backgroundImage: `url(${copy.image || ASSETS.catalogue})` }}><div className="detail-aside-image-scrim" /><div className="detail-aside-image-label"><span>{copy.eyebrow}</span><strong>NESCO Elevators</strong></div></div><div className="detail-aside-copy"><div className="section-kicker">NESCO / focus</div><h2>{isContact ? <>Let’s make the next<br /><em>step practical.</em></> : isServices ? <>What we do<br /><em>for every lift stage.</em></> : path.startsWith("/projects") ? <>Project detail<br /><em>that builds trust.</em></> : <>The detail is where<br /><em>confidence lives.</em></>}</h2><p>{isContact ? "Share your requirement with the NESCO team and we will respond with a clear next step." : "A more complete view of the building, the equipment and the practical decisions behind the work."}</p><div className="detail-aside-points"><span><b>01</b>Understand</span><span><b>02</b>Plan</span><span><b>03</b>Deliver</span></div></div></aside><div className="detail-content">{isContact ? <ContactForm /> : isFaq ? <Faq /> : <DetailBody path={path} />}</div></div></section>
    {!isContact && <section className="contact-band"><div className="container contact-band-inner"><div><div className="section-kicker light">Next step</div><h2>Have a building<br /><em>to move?</em></h2></div><ButtonLink href="/contact">Share your requirement</ButtonLink></div></section>}
  </>;
}

function DetailBody({ path }: { path: string }) {
  const detail = servicePageData[path] || productPageData[path] || projectPageData[path];
  if (detail) { const detailImage = "image" in detail ? detail.image : path.startsWith("/services") ? ASSETS.service : ASSETS.catalogue; const detailCategory = "category" in detail && typeof detail.category === "string" ? detail.category : "NESCO detail"; return <div className="detail-page-split"><div className="detail-page-image" style={{ backgroundImage: `url(${detailImage})` }}><span>{"category" in detail ? "PROJECT VISUAL" : "NESCO VISUAL"}</span></div><div className="detail-block"><span className="section-kicker">{detailCategory}</span><p className="lead small">{detail.intro}</p><div className="detail-list detail-page-list">{detail.items.map((item) => <div key={item}><Check size={17} />{item}</div>)}</div><p className="fine-print">Final suitability, availability, specification and project scope are confirmed after understanding the building, equipment and requirement.</p><ButtonLink href="/contact">Discuss this requirement</ButtonLink></div></div>; }
  if (path === "/services") return <div className="detail-block services-detail-block"><p className="lead small">NESCO Elevators provides complete elevator and electrical solutions, with each service shaped around the building, the equipment and the project requirement.</p><div className="service-tiles">{serviceCards.map(([no, title, desc, servicePath, image]) => <Link href={servicePath} key={no} className="service-tile"><div className="service-tile-image" style={{ backgroundImage: `url(${image})` }}><span>SERVICE {no}</span></div><div className="service-tile-copy"><h3>{title}</h3><p>{desc}</p><ArrowUpRight size={17} /></div></Link>)}</div><div className="approved-company-box"><Check size={18} /><span>From installation and erection to repair, maintenance, modernization and technical consultancy, NESCO keeps the next step clear and practical.</span></div></div>;
  if (path === "/products") return <div className="detail-block products-detail-block"><p className="lead small">Explore the elevator categories NESCO can discuss. Select a product tile to view its dedicated detail page; final suitability and scope are confirmed for each project.</p><div className="product-tiles">{productCards.map(([title, desc, image], index) => <Link className="product-tile" href={productRoutes[title] || "/products"} key={title}><div className="product-tile-image" style={{ backgroundImage: `url(${image})` }}><span>PRODUCT {String(index + 1).padStart(2, "0")}</span></div><div className="product-tile-copy"><h3>{title}</h3><p>{desc}</p><ArrowUpRight size={17} /></div></Link>)}</div></div>;
  if (path === "/industries") return <div className="detail-block"><p className="lead small">Start with the setting, the users and the operational context. Then shape the lift discussion around what the building needs.</p><div className="industry-tiles">{industryTiles.map(([title, desc, Icon]) => <div className="industry-tile" key={title}><div className="industry-graphic"><Icon size={30} /></div><div><h3>{title}</h3><p>{desc}</p></div><ArrowUpRight size={17} /></div>)}</div></div>;
  if (path === "/modernization") return <div className="detail-block"><p className="lead small">Possible modernization components can include the following, subject to assessment and confirmed scope:</p><div className="detail-list">{["Control systems & V3F drives", "Safety and control components", "LOP / COP panels", "Door sensors and operators", "Lift ropes", "Cabin-related works"].map((item) => <div key={item}><Check size={17} />{item}</div>)}</div><p className="fine-print">Supply, installation, testing and commissioning are included only where applicable to the confirmed project scope.</p></div>;
  if (path === "/maintenance") return <div className="detail-block"><p className="lead small">A maintenance program can be built around systematic inspections, preventive servicing, troubleshooting, component assessment and targeted repairs.</p><div className="maintenance-steps"><span><b>01</b>Inspect</span><span><b>02</b>Assess</span><span><b>03</b>Service</span><span><b>04</b>Review</span></div><p className="fine-print">Electrical systems, control systems, safety components, door operators, limit switches, hydraulic systems, pistons and valves are considered only where relevant to the lift and agreed scope.</p></div>;
  if (path === "/projects") return <div className="detail-block"><p className="lead small">Explore NESCO project categories and the type of vertical mobility work represented across each setting.</p><div className="project-profile-grid">{projectProfiles.map(([title, category, desc, image], index) => <Link href={projectRoutes[title]} className="project-profile-card" key={title}><div className="project-profile-image" style={{ backgroundImage: `url(${image})` }}><span>PROJECT {String(index + 1).padStart(2, "0")}</span></div><h3>{title}</h3><p>{category}. {desc}</p><small>VIEW PROJECT PROFILE <ArrowUpRight size={12} /></small></Link>)}</div></div>;
  return <div className="detail-block"><p className="lead small">A clear scope, a practical plan and communication that respects the building. That is the baseline for working with NESCO Elevators.</p><div className="detail-list">{["Understand the building and the brief", "Assess relevant lift systems and site conditions", "Recommend a proportionate next step", "Keep project-specific scope visible"].map((item) => <div key={item}><Check size={17} />{item}</div>)}</div><div className="approved-company-box"><Sparkles size={18} /><span>NESCO ELEVATORS – An MSME-registered and government-approved company offering complete elevator and electrical solutions, including installation, repair, maintenance, modernization, erection, and technical consultancy.</span></div></div>;
}

function Faq() {
  const faqs = ["What services does NESCO Elevators provide?", "Can an existing lift be modernized?", "What happens during a technical site survey?", "How do I discuss AMC or preventive maintenance?"];
  const [active, setActive] = useState<number | null>(0);
  return <div className="faq-list">{faqs.map((q, index) => <div className={active === index ? "faq-item active" : "faq-item"} key={q}><button onClick={() => setActive(active === index ? null : index)}><span>{q}</span>{active === index ? <X size={18} /> : <ChevronDown size={18} />}</button>{active === index && <p>NESCO will confirm the right scope after understanding the lift, building context and requirement. Share the basics through the contact form or call the official numbers.</p>}</div>)}</div>;
}

function ContactForm() {
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");
  const submit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = event.currentTarget;
    setStatus("sending");
    try {
      const response = await fetch(NESCO_FORM_ENDPOINT, {
        method: "POST",
        body: new FormData(form),
        headers: { Accept: "application/json" },
      });
      if (!response.ok) throw new Error("Form submission failed");
      form.reset();
      setStatus("success");
      toast.success("Your enquiry has been sent to the NESCO team.");
    } catch {
      setStatus("error");
      toast.error("We could not send your enquiry. Please call NESCO directly.");
    }
  };
  return <form className="contact-form" onSubmit={submit} aria-live="polite">
    {status === "success" && <div className="success-note"><Check size={16} /> Enquiry sent to nescoelevators@outlook.in. The NESCO team can now follow up with you.</div>}
    {status === "error" && <div className="error-note"><X size={16} /> The enquiry could not be sent. Please use the official phone numbers below.</div>}
    <input type="hidden" name="_subject" value="New website enquiry — NESCO Elevators" />
    <input className="form-honeypot" type="text" name="_gotcha" tabIndex={-1} autoComplete="off" aria-hidden="true" />
    <div className="form-grid"><label>Name<input required name="name" placeholder="Your name" /></label><label>Phone<input required name="phone" placeholder="+91" /></label><label>Email<input required type="email" name="_replyto" placeholder="you@company.com" /></label><label>Service requirement<select required name="service" defaultValue=""><option value="" disabled>Select a service</option><option>New lift installation</option><option>AMC and maintenance</option><option>Modernization</option><option>Car Parking System Installation & Services</option><option>Repair support</option><option>Consultancy / site survey</option></select></label></div>
    <label>Message<textarea required name="message" rows={5} placeholder="Tell us a little about the building or lift requirement" /></label>
    <button className="button-link" type="submit" disabled={status === "sending"}>{status === "sending" ? "Sending…" : "Send enquiry"} <ArrowUpRight size={16} /></button>
    <p className="form-contact">Or call <a href="tel:+919833459273">+91 98334 59273</a> / <a href="tel:+919820567419">+91 98205 67419</a> · <a href={NESCO_WHATSAPP_URL} target="_blank" rel="noreferrer" onClick={trackWhatsappClick}>WhatsApp</a> · <a href="mailto:nescoelevators@outlook.in">Email NESCO</a></p>
    <div className="contact-address"><strong>Office</strong><span>NESCO ELEVATORS<br />Sonam Saraswati Apartment, Office No. 17, Golden Nest,<br />Near Balaji Hospital, Mira Road (East),<br />Thane – 401107, Maharashtra, India.</span></div>
  </form>;
}

export default function Home() {
  const [location] = useLocation();
  const isHome = location === "/";
  useEffect(() => { document.title = isHome ? "NESCO Elevators — Engineering Every Vertical Journey" : `${pageCopy[location]?.eyebrow || "NESCO Elevators"} — NESCO Elevators`; window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior }); }, [location, isHome]);
  if (location === "/catalogue") return <Catalogue />;
  return <div className="site-shell"><Header /><main>{isHome ? <HomePage /> : <DetailPage path={location} />}</main><Footer /><a className="whatsapp-float" href={NESCO_WHATSAPP_URL} target="_blank" rel="noreferrer" onClick={trackWhatsappClick} aria-label="Chat with NESCO Elevators on WhatsApp"><MessageCircle size={22} /><span>WhatsApp us</span></a></div>;
}

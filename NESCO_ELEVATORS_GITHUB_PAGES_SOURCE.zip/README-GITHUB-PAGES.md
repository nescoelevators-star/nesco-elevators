# NESCO Elevators — GitHub Pages build

This package contains the public website source prepared for static hosting.
The public marketing site does not include the private Manus quotation/admin backend.
Existing Manus-hosted media is referenced from the published Manus project.
